# CLAUDE.md

Read this file before writing any code, every session. These are constraints, not suggestions. Do not re-derive, re-propose, or "improve" anything marked LOCKED.

---

## PROJECT

Personal portfolio for **Shrey Mehra** — Creative Strategist, Brand & Culture. Targets: Anthropic, OpenAI, FAANG, culture-led brands.

Most visitors arrive from a cold email, are sceptical, and decide within ten seconds. Build for that visitor.

**The site must not read as AI-generated or templated.** If a section could belong to any other portfolio, it is wrong.

---

## HOW THIS REPO IS ORGANISED

```
CLAUDE.md              ← you are here. Global constraints.
/briefs                ← one file per section. Read the relevant one before building.
  00-system.md            Design tokens, motion, accessibility. Read first.
  01-hero.md
  02-ticker.md
  03-work.md
  04-brain-dump.md
  05-about.md
  06-faq.md
  07-vinyl.md
  08-contact.md
/references            ← annotated screenshots. See /references/README.md
```

**Before building any section: read `/briefs/00-system.md`, then that section's brief.** Do not work from memory of a previous session.

---

## THE THREE MARKERS

- **`[LOCKED]`** — decided. Build as stated. Do not propose alternatives.
- **`[OPEN]`** — a genuine decision, with its tradeoff stated. Ask before assuming.
- **`[GAP]`** — content only Shrey can supply. **Stub it visibly** — `[GAP: teaser sentence]` — and say so in your response. Never invent it.

---

## BUILD ORDER — STRICTLY SEQUENTIAL

`HERO → TICKER → WORK → BRAIN DUMP → ABOUT → FAQ → VINYL → CONTACT`

`PortfolioHero.tsx` already exists. Match its system exactly rather than reinventing it.

---

## HOW TO WORK

**One component at a time. Never batch.** After each, stop, show the result, wait.

**Within a component, work in four passes:**
1. Static structure — no styling refinement, no hover, no motion
2. Refine spacing, type scale, alignment
3. Behaviour — hover, click, expand
4. Motion — reveals, transitions

Never compress these into one request. Doing so is the primary cause of generic output.

**When a request is ambiguous, ask.** A wrong assumption costs more than a question.

**Never invent content or metrics.** Where a number would go, show reasoning.

**Preserve Shrey's voice.** Copy he wrote is source material. Fix typos only. Do not rewrite for tone.
